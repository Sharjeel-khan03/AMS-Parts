@extends('admin.layouts.master')

@section('content')
<div class="main-container">
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <!-- Simple Datatable start -->
            <div class="card-box mb-30">
                <div class="d-flex p-3 justify-content-between">
                    <h4 class="">Inventory List</h4>

                    <!-- <div class="">
							<a href="{{route('purchase-order.create') }}" class="btn btn-dark btn-sm" rel="content-y"
								>+ Create</a>
						</div> -->

                </div>

                <div class="pb-20">
                    <table class="data-table table stripe hover nowrap">
                        <thead>
                            <tr class="text-center">
                                <th class="table-plus datatable-nosort">S.No</th>
                                <th>Item</th>
                                <th>On Hand Quantity</th>
                                <th>Allocated Quantity</th>
                                <th>Available Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $key => $value )
                            <tr class="text-center">
                                <td class="table-plus">{{ $value->id }}</td>
                                <td>{{ $value->item_name }}</td>
                                <td>{{ $value->on_hand_quantity }}</td>
                                <td>{{ $value->allocated_quantity }}</td>
                                <td>{{ $value->available_quantity}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Simple Datatable End -->
        </div>
    </div>
</div>
@endsection