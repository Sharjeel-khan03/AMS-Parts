
<div class="footer-wrap pd-20 mb-20 card-box">
    © All Right Reserved AMS Find Parts By 2024
    <a href="https://distrocode.com/" target="_blank"
        >Distrocode</a
    >
</div>
