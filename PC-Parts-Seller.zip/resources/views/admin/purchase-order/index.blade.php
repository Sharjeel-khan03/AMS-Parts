@extends('admin.layouts.master')

@section('content')
	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">
					<div class="d-flex p-3 justify-content-between">
						<h4 class="">Purchase Orders List</h4>

						<div class="">
							<a href="{{route('purchase-order.create') }}" class="btn btn-dark btn-sm" rel="content-y"
								>+ Create</a>
						</div>

					</div>

					<div class="pb-20">
						<table class="data-table table stripe hover nowrap">
							<thead>
								<tr class="text-center">
									<th class="table-plus datatable-nosort">S.No</th>
									<th>PO No</th>
									<th>Delivery Date</th>
									<th>Ship Via</th>
									<th>Terms</th>
									<th>Total</th>
									<th class="datatable-nosort">Action</th>
								</tr>
							</thead>
							<tbody>
								@foreach ($data as $key => $value )
								<tr class="text-center">
									<td class="table-plus">{{ $value->id }}</td>
									<td>{{ $value->po_number }}</td>
									<td>{{ $value->delivery_date }}</td>
									<td>{{ $value->ship_via}}</td>
									<td>{{ $value->terms}}</td>
									<td>{{ $value->total }}</td>
									<td>
										<div class="dropdown">
											<a class="dropdown-item" href="{{ route('purchase-order.show',$value->id) }}"><i class="fa-solid fa-eye"></i></i> View</a>
										</div>
									</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
				<!-- Simple Datatable End -->
			</div>
		</div>
	</div>
@endsection
