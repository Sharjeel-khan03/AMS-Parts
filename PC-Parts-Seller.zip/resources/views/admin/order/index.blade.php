@extends('admin.layouts.master')

@section('content')
	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">
					<div class="d-flex p-3 justify-content-between">
						<h4 class="">Order List</h4>

						<div class="">
							<a href="#" class="btn btn-dark btn-sm" rel="content-y"
								>+ Create</a>
						</div>

					</div>

					<div class="pb-20">
						<table class="data-table table stripe hover nowrap">
							<thead>
								<tr class="text-center">
									<th class="table-plus datatable-nosort">Order Number</th>
									<th>Date</th>
									<th>User Name</th>
									<th>Order Name</th>
									<th>Quantity</th>
									<th>Unit Price</th>
									<th>Status</th>
									<th class="datatable-nosort">Action</th>
								</tr>
							</thead>
							<tbody>
								@foreach ($data as $order )
								{{-- @foreach ($order->user as $user ) --}}
								@foreach ($order->orderLine as $ordeline )
								@foreach ($ordeline->itemProduct as $item )
								<tr class="text-center">
									<td class="table-plus">{{ $order->id }}</td>
									<td>{{ $order->created_at}}</td>
									<td>{{$order->user->name ?? 'N/A'}}</td>
									<td>{{$item->name}}</td>
									<td>{{$ordeline->quantity }}</td>
									<td>{{$order->total }}</td>
									<td>Processing</td>
									<td>
                                        <div class="dropdown">
                                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                                href="#" role="button" data-toggle="dropdown">
                                                <i class="dw dw-more"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                                {{-- <a class="dropdown-item" href="{{ route('orders.edit',$order->id) }}"><i class="dw dw-edit2"></i> Edit</a> --}}
                                                <form id="destory" action="{{route('orders.destroy',$order->id)}}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="dropdown-item" type="submit">
                                                        <i class="dw dw-delete-3"></i> Delete
                                                    </button>
                                                </form>

													<a class="dropdown-item" href="{{ route('orders.show',$order->id) }}"><i class="fa-solid fa-eye"></i></i> View</a>
                                            </div>
                                        </div>
									</td>
								</tr>
								{{-- @endforeach --}}
								@endforeach

								@endforeach
								@endforeach



							</tbody>
						</table>
					</div>
				</div>
				<!-- Simple Datatable End -->
			</div>
		</div>
	</div>
@endsection
