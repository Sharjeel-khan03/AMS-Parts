@extends('website.layouts.master')
@section('content')
    <div class="container">
        <!-- site -->
        <div class="site">
            <!-- site__body -->
            <div class="site__body">
                <div class="block-space block-space--layout--after-header"></div>
                <div class="block">
                    <div class="container container--max--xl">

                        {{-- <div class="row">
                            <div class="col-12 col-lg-3 mt-4 mt-lg-0">
                                <div class="vehicle-form__item">
                                    <input type="text" class="form-control" placeholder="Search" aria-label="search">
                                </div>
                            </div>
                            <div class="col-12 col-lg-3">
                                <div class="vehicle-form__item vehicle-form__item--select">
                                    <input type="date" class="form-control" placeholder="Search" aria-label="search">

                                </div>
                            </div>
                            <span class="toText">To</span>
                            <div class="col-12 col-lg-3">
                                <div class="vehicle-form__item vehicle-form__item--select">
                                    <input type="date" class="form-control" placeholder="Search" aria-label="search">

                                </div>
                            </div>
                            <div class="col-12 col-lg-2">
                                <div class="vehicle-picker__actions button-style">
                                    <button type="button" class="btn btn-primary btn-sm" disabled>Filter</button>

                                    <button type="button" class="btn btn-primary btn-sm" disabled>Download</button>

                                </div>
                            </div>
                        </div> --}}

                        <div class="row">
                            @include('dashboard.sidebar')
                            <div class="col-12 col-lg-10 mt-4 mt-lg-0">
                                <div class="search_bar"> 
                                    <div class="row">
                                        <div class="col-12 col-lg-3 mt-4 mt-lg-0">
                                            <div class="vehicle-form__item">
                                                <input type="text" class="form-control" placeholder="Search" aria-label="search">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-3">
                                            <div class="vehicle-form__item vehicle-form__item--select">
                                                <input type="date" class="form-control" placeholder="Search" aria-label="search">
            
                                            </div>
                                        </div>
                                        <span class="toText">To</span>
                                        <div class="col-12 col-lg-3">
                                            <div class="vehicle-form__item vehicle-form__item--select">
                                                <input type="date" class="form-control" placeholder="Search" aria-label="search">
            
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-2">
                                            <div class="vehicle-picker__actions button-style">
                                                <button type="button" class="btn btn-primary btn-sm" disabled>Filter</button>
            
                                                <button type="button" class="btn btn-primary btn-sm" disabled>Download</button>
            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header">
                                        <h5>User Invoices</h5>
                                    </div>
                                    <div class="card-divider"></div>
                                    <div class="card-table">
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">DATE</th>
                                                        <th scope="col">ORDER NUMBER</th>
                                                        <th scope="col">PURCHASE ORDER NUMBER</th>
                                                        <th scope="col">INVOICE NUMBER</th>
                                                        <th scope="col">QUANTITY</th>
                                                        <th scope="col">UNIT PRICE</th>
                                                        <th scope="col">EXTENDED PRICE</th>
                                                        <th scope="col">UOM</th>
                                                        <th scope="col">TOTAL</th>
                                                        <th scope="col">STATUS</th>
                                                        <th scope="col">SHIP FROM</th>
                                                        <th scope="col">TRACKING NUMBER</th>
                                                        <th scope="col">CURRENCY</th>
                                                        <th scope="col"></th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>

                                                        <td scope="row">02 April, 2019</td>
                                                        <td><a href="{{ route('user-order-invoice-details') }}">#8132</a>
                                                        </td>
                                                        <td>8132</td>
                                                        <td>8132</td>
                                                        <td>200</td>
                                                        <td>$2,719</td>
                                                        <td>$2,780</td>
                                                        <td>Test</td>
                                                        <td>$2,719.00</td>
                                                        <td>Pending</td>
                                                        <td>Ship & Sort Logistics</td>
                                                        <td>2356</td>
                                                        <td>USD</td>
                                                        <td>
                                                            <a href="{{ route('show.invoice.pdf') }}" target="_blank"
                                                                class="btn btn-xs btn-secondary pdf_button">Download PDF</a>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td scope="row">02 April, 2019</td>
                                                        <td><a href="{{ route('user-order-invoice-details') }}">#8132</a>
                                                        </td>
                                                        <td>8132</td>
                                                        <td>8132</td>
                                                        <td>200</td>
                                                        <td>$2,719</td>
                                                        <td>$2,780</td>
                                                        <td>Test</td>
                                                        <td>$2,719.00</td>
                                                        <td>Pending</td>
                                                        <td>Ship & Sort Logistics</td>
                                                        <td>2356</td>
                                                        <td>USD</td>
                                                        <td>
                                                            <a href="{{ route('show.invoice.pdf') }}" target="_blank"
                                                                class="btn btn-xs btn-secondary pdf_button">Download PDF</a>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td scope="row">02 April, 2019</td>
                                                        <td><a href="{{ route('user-order-invoice-details') }}">#8132</a>
                                                        </td>
                                                        <td>8132</td>
                                                        <td>8132</td>
                                                        <td>200</td>
                                                        <td>$2,719</td>
                                                        <td>$2,780</td>
                                                        <td>Test</td>
                                                        <td>$2,719.00</td>
                                                        <td>Pending</td>
                                                        <td>Ship & Sort Logistics</td>
                                                        <td>2356</td>
                                                        <td>USD</td>
                                                        <td>
                                                            <a href="{{ route('show.invoice.pdf') }}" target="_blank"
                                                                class="btn btn-xs btn-secondary pdf_button">Download PDF</a>

                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="card-divider"></div>
                                    <div class="card-footer">
                                        <ul class="pagination">
                                            <li class="page-item disabled">
                                                <a class="page-link page-link--with-arrow" href=""
                                                    aria-label="Previous">
                                                    <span class="page-link__arrow page-link__arrow--left"
                                                        aria-hidden="true"><svg width="7" height="11">
                                                            <path
                                                                d="M6.7,0.3L6.7,0.3c-0.4-0.4-0.9-0.4-1.3,0L0,5.5l5.4,5.2c0.4,0.4,0.9,0.3,1.3,0l0,0c0.4-0.4,0.4-1,0-1.3l-4-3.9l4-3.9C7.1,1.2,7.1,0.6,6.7,0.3z" />
                                                        </svg>
                                                    </span>
                                                </a>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item active" aria-current="page">
                                                <span class="page-link">
                                                    2
                                                    <span class="sr-only">(current)</span>
                                                </span>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                                            <li class="page-item page-item--dots">
                                                <div class="pagination__dots"></div>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">9</a></li>
                                            <li class="page-item">
                                                <a class="page-link page-link--with-arrow" href=""
                                                    aria-label="Next">
                                                    <span class="page-link__arrow page-link__arrow--right"
                                                        aria-hidden="true"><svg width="7" height="11">
                                                            <path d="M0.3,10.7L0.3,10.7c0.4,0.4,0.9,0.4,1.3,0L7,5.5L1.6,0.3C1.2-0.1,0.7,0,0.3,0.3l0,0c-0.4,0.4-0.4,1,0,1.3l4,3.9l-4,3.9
         C-0.1,9.8-0.1,10.4,0.3,10.7z" />
                                                        </svg>
                                                    </span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="block-space block-space--layout--before-footer"></div>
            </div>
            <!-- site__body / end -->
        </div>
        <!-- site / end -->

    </div>
    </div>
    <!-- photoswipe / end -->
@endsection
