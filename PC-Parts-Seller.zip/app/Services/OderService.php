<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Item;
use App\Models\ItemQuotes;
use Illuminate\Http\Request;

class OderService
{
    public static function index()
    {
        $data = Order::with(['user', 'orderLine.itemProduct'])->orWhere('status',1)->OrderBy('id', 'DESC')->get();
        return $data;
    }

    public static function show($id)
    {
        $data = Order::with(['user','shippingAddress','orderLine.itemProduct.itemImage'])->find($id);
        return $data;
    }

    public static function allOrder()
    {
        $data = Order::with(['user', 'orderLine.itemProduct'])->OrderBy('id', 'DESC')->get();
        return $data;   
    }

    //    public static function create()
    //    {
    //     $data = Category::get();
    //     return $data;
    //    }

    //    public static function edit($id)
    //     {
    //         $data = SubCategory::find($id);
    //         return $data;
    //     }
}
