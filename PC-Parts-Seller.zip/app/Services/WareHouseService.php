<?php

namespace App\Services;

use App\Models\Currency;
use App\Models\WareHouse;
use Illuminate\Http\Request;

class WareHouseService
{

    public static function index()
    {
        $data = WareHouse::with('currency')->get();
        return $data;
    }
    public static function store($request)
    {
        // dd($request);
        $warehouse = new WareHouse();
        $warehouse->name = $request['name'];
        $warehouse->type = $request['type'];
        $warehouse->location = $request['location'];
        $warehouse->currency_id = $request['currency_id'];
        $warehouse->save();
    }
}
