<?php

namespace App\Services;

use App\Models\Inventory;
use App\Models\Item;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLine;
use App\Models\Vendor;
use App\Models\WareHouse;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class InventoryService
{
    public static function index()
    {
        return DB::table('inventories')
            ->select([
                DB::raw('SUM(on_hand_quantity) as on_hand_quantity'),
                DB::raw('SUM(allocated_quantity) as allocated_quantity'),
                DB::raw('SUM(available_quantity) as available_quantity'),
                'items.name as item_name',
                'inventories.id as id',
            ])
            ->join('items', 'items.id', '=', 'inventories.item_id')
            ->groupBy(['inventories.item_id'])
            ->paginate(10);
    }

    public static function show($id)
    {
        $po = PurchaseOrder::with(['vendor', 'warehouse', 'lines.item'])->find($id);
        return $po;
    }
}
