<?php

namespace App\Services;

use App\Models\Item;
use App\Models\ItemQuotes;
use Illuminate\Http\Request;

class QuoteService
{
    public static function index()
    {
        $data = ItemQuotes::with(['user','item'])->Where('status',1)->get();
        return $data;
    }

    public static function show($id){
		$qo = ItemQuotes::with(['itemView','itemuser'])->find($id);
		return $qo;
	}

    public static function update($id, $data)
    {
        $dataupdate = ItemQuotes::find($id);
        $dataupdate->update([
			'company_offer' => $data['company_offer'] ,
			'status' => 1,
		]);
		return $dataupdate;
    }

    public static function allQuote()
    {
        $data = ItemQuotes::with(['user','item'])->get();
        return $data;   
    }

}
