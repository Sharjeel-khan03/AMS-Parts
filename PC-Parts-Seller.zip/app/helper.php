<?php



function sessioncartcount()
{

    $cartItems = session('cart', []);
   return $uniqueProductCount = count($cartItems);
}
