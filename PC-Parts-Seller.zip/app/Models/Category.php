<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Category extends Model
{
	use HasFactory;

	protected $fillable = [
		"name",
	];

    protected static function boot()
    {
        parent::boot();
        static::saving(function ($model) {
            $model->slug = Str::slug($model->name);
        });
    }
    public function getParentCategory(){
        return $this->hasMany(SubCategory::class,'category_id');
    }

    public function subcaetgory(){
        return $this->belongsTo(SubCategory::class,'id');
    }

}
